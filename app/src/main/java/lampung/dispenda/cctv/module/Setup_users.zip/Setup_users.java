package lampung.dispenda.cctv.module;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import lampung.dispenda.cctv.JSONParser;
import lampung.dispenda.cctv.R;
import lampung.dispenda.cctv.config.Basic;

/**
 * Created by Chandra on 5/21/2016.
 * Activity Setup users
 */
public class Setup_users extends AppCompatActivity {
    TableLayout table_layout;
    JSONParser jParser = new JSONParser();
    private static final String TAG_SUCCESS ="success";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        Bundle bundle = getIntent().getExtras();
        String title = bundle.getString("title");
        setContentView(R.layout.setup_users);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_item);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // back button pressed
                onBackPressed();
            }
        });
        setTitle(title);
        FloatingActionButton fab =(FloatingActionButton) findViewById(R.id.fab);
        ReadDataTask m= (ReadDataTask) new ReadDataTask().execute();
        table_layout = (TableLayout) findViewById(R.id.tableLayout1);
        table_layout.removeAllViews();
        fab.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intentB;
                intentB = new Intent(Setup_users.this, Setup_form_users.class);
                intentB.putExtra("title", "Add New User");
                startActivity(intentB);

            }
        });
    }
    class ReadDataTask extends AsyncTask<String, Void, String> {
        ProgressDialog pDialog;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pDialog = new ProgressDialog(Setup_users.this);
            pDialog.setMessage("Mohon Tunggu..");
            pDialog.setIndeterminate(true);
            pDialog.setCancelable(true);
            pDialog.show();
        }
        @Override
        protected String doInBackground(String... sText) {
            String returnResult = BuildTable();
            return returnResult;
        }
        @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            pDialog.dismiss();
            if (result.equalsIgnoreCase("Exception Caught")) {
                Toast.makeText(Setup_users.this, "Unable to connect to server,please check your internet connection!", Toast.LENGTH_LONG).show();
                //reload("Users");
            }
            if (result.equalsIgnoreCase("no results")) {
                Toast.makeText(Setup_users.this, "Data empty", Toast.LENGTH_LONG).show();
                //reload("Users");

            } else {
                Log.d("BALIK DATA", result);
                TableRow rowA = new TableRow(Setup_users.this);
                rowA.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));
                String atas[] = {"NO", "USERNAME", "LOCATION", "", ""};
                for (int b = 0; b < atas.length; b++) {
                    TextView tvA = new TextView(Setup_users.this);
                    tvA.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                            TableRow.LayoutParams.WRAP_CONTENT));
                    tvA.setBackgroundResource(R.drawable.cell_shape);
                    tvA.setPadding(20, 20, 20, 20);
                    tvA.setTextColor(Color.BLACK);
                    tvA.setTextSize(12);
                    tvA.setText(atas[b]);
                    rowA.addView(tvA);
                    rowA.setBackgroundColor(Color.DKGRAY);
                }
                table_layout.addView(rowA);
                JSONArray isi_data = null;
                try {
                    isi_data = new JSONArray(result);
                    int a =0;
                    for (int i = 0; i < isi_data.length(); i++) {
                        a++;
                        JSONObject c = null;
                        try {
                            c = isi_data.getJSONObject(i);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("ARRAY BALIK DATA", String.valueOf(c));
                        String[] body ={"empty","empty","empty","empty"};
                        try {
                            body = new String[]{String.valueOf(a), c.getString("user_name"), c.getString("location_name"), "edit", "delete"};
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        TableRow row = new TableRow(Setup_users.this);
                        row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                                TableRow.LayoutParams.WRAP_CONTENT));
                        for (int j = 0; j < body.length; j++) {
                            TextView tv = new TextView(Setup_users.this);
                            tv.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                                    TableRow.LayoutParams.WRAP_CONTENT));
                            tv.setBackgroundResource(R.drawable.cell_shape);
                            tv.setPadding(5, 5, 5, 5);
                            String trow = "";
                            if(body[j].equals("null")){
                                trow = "";
                            }else{
                                trow = body[j];
                            }
                            tv.setText(trow);
                            tv.setTextColor(Color.MAGENTA);
                            if(j==0) {
                                tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                            }
                            row.addView(tv);
                        }
                        table_layout.addView(row);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    TableRow rowC = new TableRow(Setup_users.this);
                    rowC.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,
                            TableRow.LayoutParams.WRAP_CONTENT));
                    String atasC[] = {"-", "-", "-", "-", "-"};
                    for (int c = 0; c < atasC.length; c++) {
                        TextView tvC = new TextView(Setup_users.this);
                        tvC.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT,
                                TableRow.LayoutParams.WRAP_CONTENT));
                        tvC.setBackgroundResource(R.drawable.cell_shape);
                        tvC.setPadding(20, 20, 20, 20);
                        tvC.setTextColor(Color.BLACK);
                        tvC.setTextSize(12);
                        tvC.setText(atasC[c]);
                        rowC.addView(tvC);
                        rowC.setBackgroundColor(Color.DKGRAY);
                    }
                    table_layout.addView(rowC);
                }
            }
        }
        private String BuildTable() {
            Basic config = new Basic();
            String url = config.getSETUP_LIST_USER();
            List<NameValuePair> parameter = new ArrayList<NameValuePair>();
            parameter.add(new BasicNameValuePair("id", "0"));
            parameter.add(new BasicNameValuePair("loc", "1"));
            Log.d("URL DATA", url);
            try {
                JSONObject json = jParser.makeHttpRequest(url, "POST", parameter);
                if(String.valueOf(json).equals("null")){
                    //reload("Users");
                    return "Exception Caught";
                }else {
                    Log.d("RESULT DATA", String.valueOf(json));
                    int success = json.getInt(TAG_SUCCESS);
                    if (success == 1) {
                        JSONArray daftarUser = json.getJSONArray("data");
                        return String.valueOf(daftarUser);
                    } else {
                        return "no results";
                    }
                }
            }catch (JSONException e) {
                e.printStackTrace();
                Log.d("URL DATA ERROR", String.valueOf(e));
                return "Exception Caught";
            }
            //return "Exception Caught";
        }
    }

}
