package lampung.dispenda.cctv;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

import lampung.dispenda.cctv.module.Setup_user;

/**
 * Created by Chandra on 5/19/2016.
 */
public class TableAdapter  extends BaseAdapter {

    public TableAdapter(Setup_user setup_user, ArrayList<Table> isi_table) {

    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
